<!DOCTYPE html>
<html lang="en">
<head></head>
<body>
	
<div class="container-fluid">
  <div class="col-md-12">
  	<div class="col-md-12">
  		<img src="../img/oh.png">
  	</div>
  	<div class="col-md-12">
  		<h3 style="text-align:center;">Quotation</h3>
  	</div>
  	<div class="col-md-12">
  		<h3 style="text-align:right;">Date:25/09/2016</h3>
  	</div>
  	<div class="col-md-12">
  		<p><b>To</b><br>
  		Company Name<br>
  		Designation<br>
  		address<br>
  		</p>
  		<p><b>Subject:</b>
  		Quotation for banner and playcard
  		</p>
  		<table border="1">
  			<thead>
  				<tr>
  					<th style="width:50px;">SL</th>
  					<th style="width:350px;">Particulars</th>
  					<th style="width:80px;">Width</th>
  					<th style="width:80px;">Height</th>
  					<th style="width:100px;">Total Sqft</th>
  					<th style="width:100px;">Unit Price</th>
  					<th style="width:120px;">Amount</th>
  				</tr>				
  			</thead>
  			<tbody>
  				<tr>
  					<td style="text-align:center;">01</td>
  					<td style="text-align:left;">Main singboard</td>
  					<td style="text-align:right;">10'X5''</td>
  					<td style="text-align:right;">15'X11''</td>	
  					<td style="text-align:right;">600</td>
  					<td style="text-align:right;">1568</td>
  					<td style="text-align:right;">1568</td>
  				</tr>
  			</tbody>
  			<tfoot>
  				<tr>
  					<td colspan="6" style="text-align:right;">Total Amount Tk</td>
  					<td style="text-align:right;">1568</td>
  				</tr>
  					<td colspan="6" style="text-align:right;">Vat %</td>
  					<td style="text-align:right;">5</td>
  				<tr>
  					<td colspan="6" style="text-align:right;">Total Amount Tk (Including Vat)</td>
  					<td style="text-align:right;">1685</td>
  				</tr>
  				<tr>
  				</tr>
  			</tfoot>
  		</table>
  		<div class="col-md-12">
  			<p style="text-align:left;"><b>Taka In Word:</b></p>
  		</div>
  		<div class="col-md-12">
  			<p style="text-align:left;"><b>Note:</b></p>
  		</div>
  		<div class="col-md-12" style="margin-top:100px;">
	  		<div class="col-md-4" style="float:left;">
	  			<p style="text-align:left;"><b>Receiver's Signature</b></p>
	  		</div>
	  		<div class="col-md-4" style="float:right;">
	  			<p style="text-align:left;"><b>OH (Out of Home)</b></p>
	  		</div>
	  	</div>
  	</div>
  </div>
</div>


</body>
</html>