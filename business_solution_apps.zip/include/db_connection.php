<?php
// Establishing connection with server..
  $connection = mysql_connect("abdulkaiyum.com", "kaiyum123", "X42e77HHOmikAH");

// Selecting Database 
  $db = mysql_select_db("kaiyum12_oh16", $connection);
  ?>