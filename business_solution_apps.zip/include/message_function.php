<?php
$msg_save='Data save successfully';
$msg_save_fail='Data not saved';
$msg_update='Data update successfully';
$msg_update_fail='Data not updated';
$msg_delete='Data deleted successfully';
$msg_delete_fail='Data not deleted';


$msg_not_match='Password not matched';

?>