<?php 
// user status for user creation
$user_type=array(1=>"Super Admin",2=>"Admin",3=>"General");
$status=array(1=>"Active",2=>"Inactive");
$division_bd=array(1=>"Dhaka",2=>"Chittagong",3=>"Khulna",4=>"Rajshahi",5=>"Barisal",6=>"Sylhet",7=>"Rangpur",8=>"Mymensingh"); 
$production_status=array(1=>"Not Yet Started",2=>"On Going",3=>"Finish");
$bill_status=array(1=>"Not-Billed",2=>"Billed");

?>